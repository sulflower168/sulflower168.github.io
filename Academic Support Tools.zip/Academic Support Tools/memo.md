

>APIキー
~~~js
const firebaseConfig = {
    apiKey: "AIzaSyBhfFiNXhqB5Lko49xQD6SonIJf_f5Wh0Q",
    authDomain: "academic-experiments-project.firebaseapp.com",
    projectId: "academic-experiments-project",
    storageBucket: "academic-experiments-project.firebasestorage.app",
    messagingSenderId: "479824505322",
    appId: "1:479824505322:web:c42a6734dcac994697aa93",
    measurementId: "G-9EE5NBZZ4D"
};
~~~

~~~text

~~~

~~~html
<section class="section box">
                                <div class="question-box">
                                    <div class="question-box-info">
                                        <!-- 音声ファイル -->
                                        <audio src="../../../audio/itpass/R06/q1/it_R06_01_all.wav" autoplay></audio>
                                        <audio id="myAudio" src="../../../audio/itpass/R06/q1/it_R06_01_question.wav"></audio>
                                        <p id="question">マーケティングオートメーション(MA)に関する記述として，最も適切なものはどれか。</p>
                                        <!-- 再生・停止ボタン -->
                                        <a href="#" id="toggleButton"><!--再生--></a>
                                    </div>
                                </div>
                                <div class="question-options">
                                    <!-- 音声ファイル -->

                                    <p class="center">下記の中から回答してください</p>
                                    <ol class="question-options">
                                        <li><span>ア</span><p>企業内に蓄積された大量のデータを分析して，事業戦略などに有効活用する。</p></li>
                                        <li><span>イ</span><p>小売業やサービス業において，販売した商品単位の情報の収集・蓄積及び分析を行う。</p></li>
                                        <li><span>ウ</span><p>これまで人間が手作業で行っていた定型業務を，AIや機械学習などを取り入れたソフトウェアのロボットが代行することによって自動化や効率化を図る。</p></li>
                                        <li><span>エ</span><p>見込み顧客の抽出，獲得，育成などの営業活動を効率化する。</p></li>
                                    </ol>
                                </div>
                                <p id="result">音声入力の結果: <span id="userInput">-</span></p>
                                <p id="feedback">-</p>
                                <div class="button-area next-question">
                                    <button onclick="startRecognition()" class="ask-questions-button">音声で回答する</button>
                                </div>
                                <div class="button-area">
                                    <a href="./q2.html" class="button">次の問題へ</a>
                                </div>
                            </section>
~~~

