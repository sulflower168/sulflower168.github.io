## HTML・CSS関連メモ（備忘録）

---
#### パスワードを伏字にする
~~~html
<form>
    <label for="password">パスワード：</label>
    <input type="password" id="password" name="password" placeholder="パスワードを入力してください">
    <input type="submit" value="送信">
</form>
~~~
input type=”password”でパスワード入力欄を伏字表示にする方法は、HTMLのコードを使って、ユーザーがパスワードを入力する項目を伏字にする方法です。

・https://ui-hack.com/programming/html_css/html_password_obfuscation/

---
#### ユーザーID、パスワード、textboxのボーダー
~~~css
border-width: 1em;
~~~

・https://developer.mozilla.org/ja/docs/Web/CSS/border-width

---
#### ホバー関連
###### ホバーしたら薄くなる
~~~css
p a:hover{ 
	opacity:0.5;
	transition:0.3s;
}
~~~
opacity:0.5;で画像の不透明度を調整します。
0.0～1.0の値で指定します。0.0は完全な透明、1.0は完全な不透明です。今回は0.5なので半透明になります。

transition:0.3s;でホバーして変化するときの所要時間を指定します。
今回は0.3sなので、ホバーしたら0.3秒かけて画像が薄くなります。

・https://www.omakase.net/blog/2022/05/img-hover.html

---
#### 日記みたいな
2024.10.17 開発開始。しばらくHTMLの勉強になりそう……。
2024.10.18 オーケー、完全に理解した（何もわかってない）。明日からホーム画面つくる。
2024.10.20 ホーム画面完成！　でも画面がみにくい……。明日はCSSを書く。
2024.10.21 CSS複雑すぎ！！　なんだこれは、たまげたな。
2024.10.22 CSS？　なにそれ？おいしいの？　『:befor, :after』！？
2024.10.23 劇的ビフォーアフター。CSS凄いな。なんということでしょう。
2024.10.24 結構いい感じじゃね？　「フラット2.0」デザインいい！！
2024.10.25 CSS、完全に理解した。明日からツール関連つくる。
2024.10.27 あかん、何も分からない。CSS？なにそれ？おいしいの？